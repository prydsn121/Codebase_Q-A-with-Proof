package com.chatapp.chatapp_redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatappRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatappRedisApplication.class, args);
	}

}
