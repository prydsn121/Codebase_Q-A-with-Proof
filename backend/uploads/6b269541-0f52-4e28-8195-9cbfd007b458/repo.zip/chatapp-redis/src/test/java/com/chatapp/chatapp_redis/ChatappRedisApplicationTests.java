package com.chatapp.chatapp_redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatappRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
