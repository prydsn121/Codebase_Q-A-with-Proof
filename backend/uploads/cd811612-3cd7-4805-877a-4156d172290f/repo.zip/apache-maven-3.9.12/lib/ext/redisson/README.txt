This directory is intended to contain Redisson [1] JARs for Maven Resolver Named Locks using Redisson.

See here [2] on how to add necessary JARs.

[1] https://github.com/redisson/redisson
[2] https://maven.apache.org/resolver/maven-resolver-named-locks-redisson/index.html#installation-testing
